/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

@FunctionalInterface
interface Sayable 
{
    String say(String message);
}

public class LambdaExample 
{
    public static void main(String[] args) 
	{
        	// use lambda expression to implement the Sayable interface

        	Sayable sayable = (message) -> "Hello, " + message + "! Welcome To Test";

        	// calling say method and printing the result

        	System.out.println(sayable.say("Bhavesh Wani"));
    	}
}


