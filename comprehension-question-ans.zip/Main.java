/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main {
    public static void main(String[] args) {
        int[] crates = {1, 0, 2, 0, 3, 0, 4};
        moveEmptyCrates(crates);
        for (int crate : crates) {
            System.out.print(crate + " ");
        }
    }

    public static void moveEmptyCrates(int[] crates) {
        int i = 0;
        for (int j = 0; j < crates.length; j++) {
            if (crates[j] != 0) {
                int temp = crates[i];
                crates[i] = crates[j];
                crates[j] = temp;
                i++;
            }
        }
    }
}
